/*************************************************************************
* Author: Jason Long
* Date: 11/24/2016
* Assignment: Final Project
*************************************************************************/

#include "Controller.hpp"
using std::cin;

int main() {
	Controller cont;
	cont.inputReceiver();

	cin.get();
}